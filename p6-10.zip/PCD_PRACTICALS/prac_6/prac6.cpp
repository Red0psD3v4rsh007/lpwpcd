#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <map>
#include <cctype>

using namespace std;

struct Symbol
{
    string name;
    string dataType;
    string address;
    bool isArray;
    int arraySize;
};

map<string, Symbol> symbolTable;
int nextAddress = 1000;

bool isType(string word)
{
    return word == "int" ||
           word == "float" ||
           word == "char" ||
           word == "string";
}

bool isIdentifier(string word)
{
    if (word.empty())
        return false;

    if (!isalpha(word[0]) && word[0] != '_')
        return false;

    for (int i = 1; i < word.length(); i++)
    {
        if (!isalnum(word[i]) && word[i] != '_')
            return false;
    }

    return true;
}

bool isInteger(string value)
{
    if (value.empty())
        return false;

    for (char c : value)
    {
        if (!isdigit(c))
            return false;
    }

    return true;
}

bool isNumber(string value)
{
    bool dot = false;
    bool digit = false;

    if (value.empty())
        return false;

    for (char c : value)
    {
        if (isdigit(c))
        {
            digit = true;
        }
        else if (c == '.' && !dot)
        {
            dot = true;
        }
        else
        {
            return false;
        }
    }

    return digit;
}

bool isStringLiteral(string value)
{
    return value.length() >= 2 &&
           value[0] == '"' &&
           value[value.length() - 1] == '"';
}

bool isCharLiteral(string value)
{
    return value.length() == 3 &&
           value[0] == '\'' &&
           value[2] == '\'';
}

string removeSpaces(string s)
{
    string result;

    for (char c : s)
    {
        if (!isspace(c))
            result += c;
    }

    return result;
}

bool validValue(string type, string value)
{
    if (type == "int")
        return isInteger(value);

    if (type == "float")
        return isNumber(value);

    if (type == "char")
        return isCharLiteral(value);

    if (type == "string")
        return isStringLiteral(value);

    return false;
}

string generateAddress()
{
    string address = "0x" + to_string(nextAddress);
    nextAddress += 4;
    return address;
}

bool insertSymbol(string name, string type,
                  bool isArray, int arraySize,
                  int line)
{
    if (symbolTable.find(name) != symbolTable.end())
    {
        cout << "Line " << line
             << ": REDECLARATION ERROR -> '"
             << name << "' is already declared.\n";

        return false;
    }

    Symbol s;

    s.name = name;
    s.dataType = type;
    s.address = generateAddress();
    s.isArray = isArray;
    s.arraySize = arraySize;

    symbolTable[name] = s;

    return true;
}

bool checkDeclarationSyntax(string line, int lineNumber)
{
    if (line.empty())
        return false;

    if (line.back() != ';')
    {
        cout << "Line " << lineNumber
             << ": SYNTAX ERROR -> Missing ';'.\n";

        return false;
    }

    return true;
}

void processDeclaration(string line, int lineNumber)
{
    cout << "\nLine " << lineNumber
         << ": Checking declaration -> "
         << line << endl;

    if (!checkDeclarationSyntax(line, lineNumber))
        return;

    line.pop_back();

    stringstream ss(line);

    string type;
    ss >> type;

    if (!isType(type))
    {
        cout << "Line " << lineNumber
             << ": SYNTAX ERROR -> Invalid data type '"
             << type << "'.\n";

        return;
    }

    string remaining;
    getline(ss, remaining);

    remaining = removeSpaces(remaining);

    if (remaining.empty())
    {
        cout << "Line " << lineNumber
             << ": SYNTAX ERROR -> Identifier expected.\n";

        return;
    }

    stringstream variableStream(remaining);
    string declaration;

    while (getline(variableStream, declaration, ','))
    {
        if (declaration.empty())
        {
            cout << "Line " << lineNumber
                 << ": SYNTAX ERROR -> Invalid declaration.\n";
            continue;
        }

        string name;
        string value;

        bool isArray = false;
        int arraySize = 0;

        size_t openBracket = declaration.find('[');

        if (openBracket != string::npos)
        {
            size_t closeBracket =
                declaration.find(']');

            if (closeBracket == string::npos)
            {
                cout << "Line " << lineNumber
                     << ": SYNTAX ERROR -> Missing ']'.\n";
                continue;
            }

            name = declaration.substr(0, openBracket);

            string size =
                declaration.substr(
                    openBracket + 1,
                    closeBracket - openBracket - 1);

            if (!isInteger(size))
            {
                cout << "Line " << lineNumber
                     << ": SYNTAX ERROR -> Invalid array size.\n";
                continue;
            }

            arraySize = stoi(size);

            if (arraySize <= 0)
            {
                cout << "Line " << lineNumber
                     << ": SEMANTIC ERROR -> Array size must be positive.\n";
                continue;
            }

            if (closeBracket != declaration.length() - 1)
            {
                cout << "Line " << lineNumber
                     << ": SYNTAX ERROR -> Invalid array declaration.\n";
                continue;
            }

            isArray = true;
        }
        else
        {
            size_t equalSign =
                declaration.find('=');

            if (equalSign != string::npos)
            {
                name =
                    declaration.substr(0, equalSign);

                value =
                    declaration.substr(equalSign + 1);

                if (value.empty())
                {
                    cout << "Line " << lineNumber
                         << ": SYNTAX ERROR -> Value expected after '='.\n";
                    continue;
                }
            }
            else
            {
                name = declaration;
            }
        }

        if (!isIdentifier(name))
        {
            cout << "Line " << lineNumber
                 << ": SYNTAX ERROR -> Invalid identifier '"
                 << name << "'.\n";

            continue;
        }

        if (isArray)
        {
            insertSymbol(
                name,
                type,
                true,
                arraySize,
                lineNumber
            );

            continue;
        }

        if (!value.empty())
        {
            if (!validValue(type, value))
            {
                cout << "Line " << lineNumber
                     << ": TYPE MISMATCH ERROR -> '"
                     << value
                     << "' cannot be assigned to "
                     << type
                     << " variable '"
                     << name << "'.\n";

                continue;
            }
        }

        insertSymbol(
            name,
            type,
            false,
            0,
            lineNumber
        );
    }
}

void processAssignment(string line, int lineNumber)
{
    cout << "\nLine " << lineNumber
         << ": Checking assignment -> "
         << line << endl;

    if (line.empty() || line.back() != ';')
    {
        cout << "Line " << lineNumber
             << ": SYNTAX ERROR -> Missing ';'.\n";
        return;
    }

    line.pop_back();

    size_t equalSign = line.find('=');

    if (equalSign == string::npos)
    {
        cout << "Line " << lineNumber
             << ": SYNTAX ERROR -> '=' expected.\n";
        return;
    }

    string left =
        line.substr(0, equalSign);

    string right =
        line.substr(equalSign + 1);

    left = removeSpaces(left);
    right = removeSpaces(right);

    if (left.empty() || right.empty())
    {
        cout << "Line " << lineNumber
             << ": SYNTAX ERROR -> Invalid assignment.\n";
        return;
    }

    size_t openBracket = left.find('[');

    if (openBracket != string::npos)
    {
        size_t closeBracket = left.find(']');

        if (closeBracket == string::npos)
        {
            cout << "Line " << lineNumber
                 << ": SYNTAX ERROR -> Missing ']'.\n";
            return;
        }

        string arrayName =
            left.substr(0, openBracket);

        string index =
            left.substr(
                openBracket + 1,
                closeBracket - openBracket - 1);

        if (symbolTable.find(arrayName) ==
            symbolTable.end())
        {
            cout << "Line " << lineNumber
                 << ": NOT DECLARATION ERROR -> '"
                 << arrayName
                 << "' is not declared.\n";

            return;
        }

        Symbol &s = symbolTable[arrayName];

        if (!s.isArray)
        {
            cout << "Line " << lineNumber
                 << ": SEMANTIC ERROR -> '"
                 << arrayName
                 << "' is not an array.\n";

            return;
        }

        if (!isInteger(index))
        {
            cout << "Line " << lineNumber
                 << ": SEMANTIC ERROR -> Invalid array index.\n";

            return;
        }

        int indexValue = stoi(index);

        if (indexValue < 0 ||
            indexValue >= s.arraySize)
        {
            cout << "Line " << lineNumber
                 << ": ARRAY BOUNDS ERROR -> Index "
                 << indexValue
                 << " is outside array '"
                 << arrayName
                 << "'.\n";

            return;
        }

        if (!validValue(s.dataType, right))
        {
            cout << "Line " << lineNumber
                 << ": TYPE MISMATCH ERROR -> Value '"
                 << right
                 << "' does not match array type "
                 << s.dataType << ".\n";

            return;
        }

        cout << "Line " << lineNumber
             << ": Array assignment is valid.\n";

        return;
    }

    if (symbolTable.find(left) ==
        symbolTable.end())
    {
        cout << "Line " << lineNumber
             << ": NOT DECLARATION ERROR -> '"
             << left
             << "' is not declared.\n";

        return;
    }

    Symbol &s = symbolTable[left];

    if (!validValue(s.dataType, right))
    {
        cout << "Line " << lineNumber
             << ": TYPE MISMATCH ERROR -> Value '"
             << right
             << "' does not match type "
             << s.dataType
             << ".\n";

        return;
    }

    cout << "Line " << lineNumber
         << ": Assignment is semantically valid.\n";
}

void displaySymbolTable()
{
    cout << "\n\n";
    cout << "====================================================\n";
    cout << "                 SYMBOL TABLE\n";
    cout << "====================================================\n";

    cout << "Name\t\tData Type\tAddress\n";
    cout << "----------------------------------------------------\n";

    for (auto &entry : symbolTable)
    {
        Symbol s = entry.second;

        cout << s.name << "\t\t"
             << s.dataType;

        if (s.isArray)
            cout << "[" << s.arraySize << "]";

        cout << "\t\t"
             << s.address << endl;
    }

    cout << "====================================================\n";
}

int main()
{
    ifstream file("input.txt");

    if (!file)
    {
        cout << "ERROR: input.txt not found.\n";
        return 1;
    }

    string line;
    int lineNumber = 0;

    cout << "====================================================\n";
    cout << "       SYNTAX AND SEMANTIC ANALYZER\n";
    cout << "====================================================\n";

    while (getline(file, line))
    {
        lineNumber++;

        while (!line.empty() &&
               isspace(line[0]))
        {
            line.erase(0, 1);
        }

        if (line.empty())
            continue;

        if (line.length() >= 2 &&
            line[0] == '/' &&
            line[1] == '/')
        {
            continue;
        }

        string firstWord;

        stringstream ss(line);
        ss >> firstWord;

        if (isType(firstWord))
        {
            processDeclaration(line, lineNumber);
        }
        else
        {
            processAssignment(line, lineNumber);
        }
    }

    displaySymbolTable();

    file.close();

    return 0;
}